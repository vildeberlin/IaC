variable "network_name" {
  description = "Name of backend network"
}

variable "network_subnet_name" {
  description = "Name of backend subnet"
}

variable "network_subnet_cidr" {
  description = "CIDR for backend network"

}

variable "network_router_name" {
  description = "Name for backend router"

}

variable "ntnu_internal_network" {
  description = "Name of the external network in SkyHiGh"
  default     = "ntnu-internal"
}

# Dette er de subnettsene vi skal ha, en for frontend, en for backend og en for database
variable "subnet" {
  description = "Liste over subnett"
  type        = map(string)
}